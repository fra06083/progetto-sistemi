# MultiPandOS

To compile the project:
```bash
mkdir -p build && pushd build && cmake .. && make && popd
```

https://prod.liveshare.vsengsaas.visualstudio.com/join?FB4916D5B8A15B73CF45DA6874342804D3B0
